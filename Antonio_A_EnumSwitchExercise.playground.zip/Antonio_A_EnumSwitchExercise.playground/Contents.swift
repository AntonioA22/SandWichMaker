import UIKit

enum bread {
    case rye
    case wheat
    case white
}

var breadchoice = bread.wheat

enum condiment {
    case mustard
    case mayo
    case PBJ
}

var condimentchoice = condiment.mayo

enum meat {
    case salami
    case ham
    case none
}

var meatchoice = meat.ham

enum extras {
    case lettuce
    case tomatoes
    case cheese
    case ketchup
    case eggs
    case jalepenos
}

var extraschoice = extras.cheese
